package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.api.minecraft.client.gui.IFontRenderer
import net.ccbluex.liquidbounce.api.minecraft.util.IResourceLocation
import net.ccbluex.liquidbounce.features.module.modules.color.CustomColor
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.FadeState.*
import net.ccbluex.liquidbounce.ui.client.hud.element.elements.Notifications.Companion.shadowValue
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.render.EaseUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11
import java.awt.Color                                                            //By Ruoper
import kotlin.math.max                                                          //By Ruoper
import kotlin.math.pow                                                         //By Ruoper
//By Ruoper
/**
 * CustomHUD Notification element
 *///By Ruoper
@ElementInfo(name = "Notifications")//By Ruoper
class Notifications(x: Double = 0.0, y: Double = 0.0, scale: Float = 1F, side: Side = Side(Side.Horizontal.RIGHT, Side.Vertical.DOWN)) : Element(x, y, scale, side) {
    companion object {
        val shadowValue = BoolValue("Shadow", true)
        val styleValue = ListValue("Mode", arrayOf("New"), "New")
    }

    /**
     * Example notification for CustomHUD designer
     */
    private val exampleNotification = Notification("Notification", "This is an example notification.", NotifyType.INFO)


    /**
     * Draw element
     */
    override fun drawElement(): Border? {
        LiquidBounce.hud.notifications.map { it }.forEachIndexed { index, notify ->
            GL11.glPushMatrix()

            if (notify.drawNotification(
                    index,
                    Fonts.font35,
                    200,
                    this.renderX.toFloat(),
                    this.renderY.toFloat(),
                    scale,
                    contentShadow = false,
                    titleShadow = false,
                    whiteText = true,
                    modeColored = true,
                    parent = Companion
                )
            ) {
                LiquidBounce.hud.notifications.remove(notify)
            }

            GL11.glPopMatrix()
        }

        if (classProvider.isGuiHudDesigner(mc.currentScreen)) {
            if (!LiquidBounce.hud.notifications.contains(exampleNotification)) {
                LiquidBounce.hud.addNotification(exampleNotification)
            }

            exampleNotification.fadeState = STAY
            exampleNotification.displayTime = System.currentTimeMillis()

            return Border(-exampleNotification.width.toFloat(), -exampleNotification.height.toFloat(), 0F, 0F)
        }

        return null
    }

}


class Notification(
    val title: String,
    val content: String,
    val type: NotifyType,
    val time: Int = 1500,
    private val animeTime: Int = 500
) {
    private var s: String? = null
    var width = 100
    var height = 30
    var x = 0F

    private var textLengthtitle = 0
    private var textLengthcontent = 0
    private var textLength = 0f

    init {
        textLengthtitle = Fonts.font35.getStringWidth(title)
        textLengthcontent = Fonts.font35.getStringWidth(content)
        textLength = textLengthcontent.toFloat() + textLengthtitle.toFloat()
    }

    var fadeState = IN
    private var nowY = -height
    var displayTime = System.currentTimeMillis()
    private var animeXTime = System.currentTimeMillis()
    private var animeYTime = System.currentTimeMillis()


    fun easeInBack(x: Double): Double {
        val c1 = 1.70158
        val c3 = c1 + 1

        return c3 * x * x * x - c1 * x * x
    }

    fun easeOutBack(x: Double): Double {
        val c1 = 1.70158
        val c3 = c1 + 1

        return 1 + c3 * (x - 1).pow(3) + c1 * (x - 1).pow(2)
    }

    /**
     * Draw notification
     */
    fun drawNotification(
        index: Int, font: IFontRenderer, alpha: Int, x: Float, y: Float, scale: Float,
        contentShadow: Boolean,
        titleShadow: Boolean,
        whiteText: Boolean,
        modeColored: Boolean,
        parent: Notifications.Companion

    ): Boolean {
        this.width = 100.coerceAtLeast(
            font.getStringWidth(content)
                .coerceAtLeast(font.getStringWidth(title)) + 15
        )
        val realY = -(index + 1) * height
        val nowTime = System.currentTimeMillis()
        var transY = nowY.toDouble()
        font.getStringWidth("$title: $content")

        val textColor: Int = if (whiteText) {
            Color(255, 255, 255).rgb
        } else {
            Color(10, 10, 10).rgb
        }
        val error = MinecraftInstance.classProvider.createResourceLocation("tomk/notification/new/cross.png")
        val successful =
            MinecraftInstance.classProvider.createResourceLocation("tomk/notification/new/tick.png")
        val warn =
            MinecraftInstance.classProvider.createResourceLocation("tomk/notification/new/warning.png")
        val info = MinecraftInstance.classProvider.createResourceLocation("tomk/notification/new/info.png")
        // Y-Axis Animation
        if (nowY != realY) {
            var pct = (nowTime - animeYTime) / animeTime.toDouble()
            if (pct > 1) {
                nowY = realY
                pct = 1.0
            } else {
                pct = EaseUtils.easeOutExpo(pct)
            }
            transY += (realY - nowY) * pct
        } else {
            animeYTime = nowTime
        }

        // X-Axis Animation
        var pct = (nowTime - animeXTime) / animeTime.toDouble()
        when (fadeState) {
            IN -> {
                if (pct > 1) {
                    fadeState = STAY
                    animeXTime = nowTime
                    pct = 1.0
                }
                pct = easeOutBack(pct)
            }

            STAY -> {
                pct = 1.0
                if ((nowTime - animeXTime) > time) {
                    fadeState = OUT
                    animeXTime = nowTime
                }
            }

            OUT -> {
                if (pct > 1) {
                    fadeState = END
                    animeXTime = nowTime
                    pct = 1.0
                }
                pct = 1 - easeInBack(pct)
            }

            END -> {
                return true
            }
        }
        val transX = width - (width * pct) - width
        GL11.glTranslated(transX, transY, 0.0)
        // draw notify
        val style = parent.styleValue.get()



        if (type == NotifyType.SUCCESS)
            s = "SUCCESS";
        else if (type == NotifyType.ERROR)
            s = "ERROR";
        else if (type == NotifyType.WARNING)
            s = "WARNING";
        else if (type == NotifyType.INFO)
            s = "INFO";
        if (style.equals("New")) {
            if (s == "INFO") {
                RenderUtils.drawRect(
                    0F,
                    0F,
                    max(
                        width - width * ((nowTime - displayTime) / (animeTime * 2F + time)) + Fonts.font40.getStringWidth(
                            content + " " + title
                        ) - 95F, 0F
                    ),
                    20f,
                    Color(0, 0, 0,0).rgb
                )

                RenderUtils.drawRect(0F, 0F, Fonts.font35.getStringWidth(content + " " + title) + 25F, 20f, Color(0, 0, 0, 100).rgb)
                Fonts.font40.drawString(content + " " + title, 20F, 7f, Color.white.rgb)
                RenderUtils.drawImage(info, -0, 0, 20, 20)
                GL11.glTranslatef(0F , -10F,0F)
                RenderUtils.drawGradientSideways(0.0, height - 1.7,
                    (width * ((nowTime - displayTime) / (animeTime * 1.5F + time))).toDouble(), height.toDouble(), Color(
                        CustomColor.r.get(),
                        CustomColor.g.get(),
                        CustomColor.b.get()).rgb, Color(CustomColor.r2.get(), CustomColor.g2.get(), CustomColor.b2.get()).rgb)
            }
            if (s == "SUCCESS") {
                RenderUtils.drawRect(
                    0F,
                    0F,
                    max(
                        width - width * ((nowTime - displayTime) / (animeTime * 2F + time)) + Fonts.font40.getStringWidth(
                            content + " " + title
                        ) - 85F, 0F
                    ),
                    20f,
                    Color(0, 0, 0,0).rgb
                )
                RenderUtils.drawRect(0F, 0F, Fonts.font40.getStringWidth(content + " " + title) + 25F, 20f, Color(0, 0, 0, 100).rgb)
                Fonts.font40.drawString(content + " " + title, 20F, 7f, Color.white.rgb)
                RenderUtils.drawImage(successful, -0, 0, 20, 20)
                GL11.glTranslatef(0F , -10F,0F)
                RenderUtils.drawGradientSideways(0.0, height - 1.7,
                    (width * ((nowTime - displayTime) / (animeTime * 1.5F + time))).toDouble(), height.toDouble(), Color(
                        CustomColor.r.get(),
                        CustomColor.g.get(),
                        CustomColor.b.get()).rgb, Color(CustomColor.r2.get(), CustomColor.g2.get(), CustomColor.b2.get()).rgb)
            }
            if (s == "ERROR") {
                RenderUtils.drawRect(
                    0F,
                    0F,
                    max(
                        width - width * ((nowTime - displayTime) / (animeTime * 2F + time)) + Fonts.font40.getStringWidth(
                            content + " " + title
                        ) - 85F, 0F
                    ),
                    20f,
                    Color(0, 0, 0,0).rgb
                )
                RenderUtils.drawRect(0F, 0F, Fonts.font40.getStringWidth(content + " " + title) + 25F, 20f, Color(0, 0, 0, 100).rgb)
                Fonts.font40.drawString(content + " " + title, 20F, 7f, Color.white.rgb)
                RenderUtils.drawImage(error, -0, 0, 20, 20)
                GL11.glTranslatef(0F , -10F,0F)
                RenderUtils.drawGradientSideways(0.0, height - 1.7,
                    (width * ((nowTime - displayTime) / (animeTime * 1.5F + time))).toDouble(), height.toDouble(), Color(
                        CustomColor.r.get(),
                        CustomColor.g.get(),
                        CustomColor.b.get()).rgb, Color(CustomColor.r2.get(), CustomColor.g2.get(), CustomColor.b2.get()).rgb)
            }
            if (s == "WARNING") {
                RenderUtils.drawRect(
                    0F,
                    0F,
                    max(
                        width - width * ((nowTime - displayTime) / (animeTime * 2F + time)) + Fonts.font40.getStringWidth(
                            content + "" + title
                        ) - 85F, 0F
                    ),
                    20f,
                    Color(0, 0, 0,0).rgb
                )

                RenderUtils.drawRect(0F, 0F, Fonts.font40.getStringWidth(content + " " + title) + 25F, 20f, Color(0, 0, 0, 100).rgb)
                Fonts.font40.drawString(content + " " + title, 20F, 7f, Color.white.rgb)
                RenderUtils.drawImage(warn, -0, 0, 20, 20)
                GL11.glTranslatef(0F , -10F,0F)
                RenderUtils.drawGradientSideways(0.0, height - 1.7,
                    (width * ((nowTime - displayTime) / (animeTime * 1.5F + time))).toDouble(), height.toDouble(), Color(
                        CustomColor.r.get(),
                        CustomColor.g.get(),
                        CustomColor.b.get()).rgb, Color(CustomColor.r2.get(), CustomColor.g2.get(), CustomColor.b2.get()).rgb)
            }
            return false
        }

        if (style == "") {
            var img: IResourceLocation? = null
            when (s) {
                "INFO" -> img = info
                "SUCCESS" -> img = successful
                "ERROR" -> img = error
                "WARNING" -> img = warn
            }
            RenderUtils.drawImage(img, 2, 4, 25, 25)
            return false
        }

        return false
    }

}

enum class NotifyType(var renderColor: Color) {
    SUCCESS(Color(0x60E092)),
    ERROR(Color(0xFF2F2F)),
    WARNING(Color(0xF5FD00)),
    INFO(Color(0x6490A7));
}

enum class FadeState { IN, STAY, OUT, END }

